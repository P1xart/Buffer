package main

import (
	"log"
	"bytes"
	"mime/multipart"
	"net/http"
)

func main() {
	for i := 0; i != 100; i++ {
		payload := bytes.Buffer{}
		writer := multipart.NewWriter(&payload)

		writer.WriteField("period_start", "2024-05-01")
		writer.WriteField("period_end", "2024-05-31")
		writer.WriteField("period_key", "month")
		writer.WriteField("indicator_to_mo_id", "227373")
		writer.WriteField("indicator_to_mo_fact_id", "0")
		writer.WriteField("value", "1")
		writer.WriteField("fact_time", "2024-05-31")
		writer.WriteField("is_plan", "0")
		writer.WriteField("auth_user_id","40")
		writer.WriteField("comment", "buffer Dupin")
		writer.Close()
		
		client := http.Client{}
		request, err := http.NewRequest("POST", "http://localhost:6700/api/buffer", &payload)
		if err != nil {
			log.Println(err)
		}
        request.Header.Add("Authorization", "Bearer 48ab34464a5573519725deb5865cc74c")
		request.Header.Add("Content-Type", writer.FormDataContentType())
		response, err := client.Do(request)
		if err != nil {
			log.Println(err)
		}
		log.Println("Отправлен запрос", i, "\nОтвет", response)
	}
}
